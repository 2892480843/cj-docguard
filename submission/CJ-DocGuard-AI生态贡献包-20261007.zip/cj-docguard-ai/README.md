# CJ-DocGuard 仓颉 AI 生态贡献

面向仓颉库维护者与 AI 编码助手的证据查询 Skill、只读 MCP 适配器和示例复现工作流。AI 助手使用陌生接口前，可以查询精确 SDK、实际平台和当前输入下有效的运行示例，并引用其尝试编号；证据不足时明确拒绝回退到历史成功。

这是 CJ-DocGuard 自研成果的独立分发仓库。原生仓颉引擎仍由[主作品仓库](https://atomgit.com/c2892480843s/cj-docguard)提供，**此仓库不能单独替代原生引擎**。分发来源与固定提交见[SOURCE.json](SOURCE.json)。Apache-2.0 许可；没有声称上游采用或已获加分。

## 交付内容

| 成果 | 入口 | 复用方式 |
|---|---|---|
| Skill（供助手阅读的操作指南） | [SKILL.md](skills/cj-docguard/SKILL.md) | 复制至自己助手识别的技能目录；需按该助手的发现规则加载 |
| MCP（供助手调用工具的协议）只读适配器 | [mcp_stdio.py](scripts/mcp_stdio.py) | Python 标准库启动，连接固定原生程序与项目配置 |
| 客户端配置示例 | [mcp-client.example.json](examples/mcp-client.example.json) | 替换绝对路径与运行库环境，按客户端格式接入 |
| 工作流 | [证据查询与复现](workflows/evidence-first.md) | 先查声明、再查当前运行证据，人工授权后独立复现 |
| 提示模板 | [使用模板](prompts/evidence-first.md) | 给助手明确环境、引用依据与拒绝条件 |
| 可审查最小仓颉项目 | [reuse-project](examples/reuse-project) | 两个SDK的加法调用和`stdout=3`断言；自建样例 |
| 测试与实测附件 | [验证说明](docs/verification.md)、[证据](evidence) | 13项协议替身测试与真实SDK验证分开记录 |
| 生态贡献申请说明 | [application.md](docs/application.md) | 提供申请对象、贡献链接、运行/复用与验证边界 |

## 安装与首次验证

需要 Python 3.11.4+、系统C编译器与真实官方仓颉SDK。当前贡献包本轮实测为macOS arm64；主作品另有历史Linux aarch64证据，Windows未支持。SDK须来自维护者审核的官方安装，不能放进被扫描项目中。

```bash
git clone https://atomgit.com/c2892480843s/cj-docguard.git
git clone https://atomgit.com/c2892480843s/cj-docguard-ai.git
cd cj-docguard
# 固定本轮原生引擎来源；这是核心代码的受测身份，不是最新版本承诺。
git checkout 8a886f73f28d29c7fe92f2ea9dbebaa205b7f68a
export CJ_DOCGUARD_SDK_1_1_3=/absolute/sdk-1.1.3/cangjie
export CJ_DOCGUARD_SDK_1_2_0=/absolute/sdk-1.2.0/cangjie
python3 scripts/dev.py build
```

阅读独立仓库`examples/reuse-project`三份文件，确认这段本地代码和断言属于自己的授权范围。以下原生CLI命令从主作品仓库根目录执行；`/absolute/cj-docguard-ai`替换为独立贡献仓库的绝对路径。

```bash
python3 scripts/dev.py run -- verify --config /absolute/cj-docguard-ai/examples/reuse-project/docguard.toml --matrix
python3 scripts/dev.py run -- check --config /absolute/cj-docguard-ai/examples/reuse-project/docguard.toml --strict
python3 scripts/dev.py run -- query --config /absolute/cj-docguard-ai/examples/reuse-project/docguard.toml --tool get_verified_examples --sdk 1.1.3 --platform Darwin-arm64 --example add
```

Linux用户须依据真实`uname`结果填写平台，例如`Linux-aarch64`，并使用该平台SDK；不得沿用macOS证据。`trusted=true`与`closed_inputs=true`只适用于已审核的随包小样例，不能直接照抄给未审查项目。

## 连接 AI 助手

复制`skills/cj-docguard`到你所用助手**实际识别**的技能目录，并确认助手读取它。只复制文件不证明加载成功；本次未在任何全局助手目录自动安装。独立包Skill内容与主作品版本逐字节一致，本轮没有新增模型遵从性实验。

客户端JSON采用常见`mcpServers`形式，仅是配置示例。将所有`/absolute/`路径、SDK路径及运行库路径替换为真实值，按你的客户端要求导入。macOS还需实际系统SDK路径，可通过`xcrun --sdk macosx --show-sdk-path`获取；Linux改用`LD_LIBRARY_PATH`并移除macOS专用字段。

适配器启动命令：

```bash
python3 /absolute/cj-docguard-ai/scripts/mcp_stdio.py --binary /absolute/cj-docguard/build/cj-docguard --config /absolute/project/docguard.toml
```

启动前设置`CJ_DOCGUARD_RUNNER=/absolute/cj-docguard/build/cjdg-runner`、登记SDK环境及实际运行库环境。主作品`scripts/dev.py`中的`sdk_env()`展示本轮实际构建/查询环境。仅执行上述命令而遗漏运行库环境可能无法启动原生程序。

`tools/list`应恰好返回`list_symbols`、`get_verified_examples`和`get_evidence`。不存在构建、验证或任意命令执行工具。有效查询仍会写私有环境探针日志、持有互斥目录，**只读指不修改项目源码和不执行登记示例**，不意味着文件系统完全无写入。

## 复用与复现

[工作流](workflows/evidence-first.md)列出工具参数、期待的返回字段、缺证据处理和导出重建。只有`RUN_VERIFIED`、`CURRENT`、`eligible=true`且断言与阶段日志完整的结果可作依据；源码改变、较新失败、错误平台、无匹配SDK、未知输入和仅编译结果都不能替代当前运行证据。新生成代码仍须独立编译测试。

协议单元测试无需仓颉SDK，使用明确标注的原生程序替身：

```bash
cd /absolute/cj-docguard-ai
python3 -m unittest discover -s tests -p test_mcp.py -v
```

真实集成复验在固定提交的主作品仓库执行：

```bash
cd /absolute/cj-docguard
python3 -m unittest discover -s tests -p test_mcp.py -v
```

后者必须先真实构建CLI并配置SDK。本轮结果为14项、零跳过；只运行前一命令不能声称SDK集成通过。

## 限制与维护

本轮仅验证工具链与文件复用，不证明AI效果提升。历史30对模型实验功能均30/30，综合基础组30/30、证据组29/30，未见提升，见[原始实验口径](https://atomgit.com/c2892480843s/cj-docguard/blob/main/docs/ai-evaluation.md)。协议固定于实现所声明版本，不宣称兼容所有客户端或最新协议。Unix资源监督不构成安全沙箱；新项目必须审核源码、依赖、断言及执行授权。遇到问题请在本仓库提出Issue，附脱敏配置、平台、SDK版本和错误输出；不要附令牌、联系方式或私人源码。
