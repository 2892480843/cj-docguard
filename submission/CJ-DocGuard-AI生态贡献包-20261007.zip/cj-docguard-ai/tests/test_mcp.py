"""Protocol unit tests using an explicitly labelled mock native executable.

The fixture validates adapter behavior; it is not SDK/evidence integration proof.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ADAPTER = ROOT / "scripts/mcp_stdio.py"


def request(method, params=None, identifier=1):
    value = {"jsonrpc": "2.0", "id": identifier, "method": method}
    if params is not None:
        value["params"] = params
    return value


INITIALIZE = request("initialize", {
    "protocolVersion": "2025-06-18", "capabilities": {},
    "clientInfo": {"name": "unit-fixture-client", "version": "1.0"},
})
INITIALIZED = {"jsonrpc": "2.0", "method": "notifications/initialized"}


class McpUnitFixtureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="cjdg-mcp-unit-")
        self.addCleanup(self.tmp.cleanup)
        self.directory = Path(self.tmp.name)
        self.config = self.directory / "project.toml"
        self.config.write_text("# Unit fixture only, not a real verified project\n", encoding="utf-8")
        self.log = self.directory / "fixture-calls.jsonl"
        self.binary = self.directory / "mock-native-unit-fixture"
        self.binary.write_text(
            f"#!{sys.executable}\n"
            "# Unit fixture only: not the native engine or real verification evidence.\n"
            "import json, pathlib, sys\n"
            f"log = pathlib.Path({str(self.log)!r})\n"
            "previous = log.read_text().splitlines() if log.exists() else []\n"
            "with log.open('a') as stream: stream.write(json.dumps(sys.argv[1:]) + '\\n')\n"
            "args = sys.argv[1:]\n"
            "if 'native-fail' in args: print('unit fixture native failure', file=sys.stderr); sys.exit(7)\n"
            "if 'bad-json' in args: print('not JSON'); sys.exit(0)\n"
            "print(json.dumps({'fixture': 'unit only', 'call': len(previous)+1, 'argv': args, 'results': []}))\n",
            encoding="utf-8",
        )
        self.binary.chmod(0o755)

    def run_messages(self, messages, *, binary=None, config=None, raw=False):
        source = messages if raw else "\n".join(json.dumps(m) for m in messages) + "\n"
        proc = subprocess.run(
            [sys.executable, str(ADAPTER), "--binary", str(binary or self.binary),
             "--config", str(config or self.config)],
            input=source.encode(), capture_output=True, timeout=8,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr.decode())
        lines = proc.stdout.decode().splitlines()
        return [json.loads(line) for line in lines]

    def initialized(self, *messages, **kwargs):
        return self.run_messages([INITIALIZE, INITIALIZED, *messages], **kwargs)

    def call(self, name, arguments=None, identifier=2):
        return request("tools/call", {"name": name, "arguments": arguments or {}}, identifier)

    def calls(self):
        return [json.loads(line) for line in self.log.read_text().splitlines()] if self.log.exists() else []

    def test_handshake_ping_notifications_and_exact_readonly_tools(self):
        responses = self.initialized(request("ping", identifier="p"), request("tools/list", identifier=3))
        self.assertEqual([r["id"] for r in responses], [1, "p", 3])
        info = responses[0]["result"]
        self.assertEqual(info["protocolVersion"], "2025-06-18")
        self.assertEqual(info["capabilities"], {"tools": {"listChanged": False}})
        self.assertEqual(responses[1]["result"], {})
        tools = responses[2]["result"]["tools"]
        self.assertEqual({t["name"] for t in tools}, {"list_symbols", "get_verified_examples", "get_evidence"})
        for tool in tools:
            self.assertTrue(tool["annotations"]["readOnlyHint"])
            self.assertFalse(tool["inputSchema"]["additionalProperties"])
            if tool["name"] != "list_symbols":
                self.assertEqual(set(tool["inputSchema"]["required"]), {"sdk", "platform"})
        self.assertEqual(self.calls(), [])

    def test_each_call_runs_fresh_native_query_with_fixed_paths(self):
        responses = self.initialized(self.call("list_symbols"), self.call("list_symbols", identifier=3))
        results = [r["result"] for r in responses[1:]]
        self.assertEqual([json.loads(r["content"][0]["text"])["call"] for r in results], [1, 2])
        for result in results:
            self.assertFalse(result["isError"])
        for argv in self.calls():
            self.assertEqual(argv[:5], ["query", "--config", str(self.config.resolve()), "--tool", "list_symbols"])

    def test_sdk_platform_and_literal_symbol_are_forwarded_without_shell(self):
        marker = self.directory / "SHOULD_NOT_EXIST"
        symbol = f"文档函数; touch {marker}; $(echo injection)"
        args = {"symbol": symbol, "example": "demo", "sdk": "1.1.3", "platform": "Darwin-arm64"}
        response = self.initialized(self.call("get_verified_examples", args))[-1]
        self.assertFalse(response["result"]["isError"])
        argv = self.calls()[0]
        self.assertEqual(argv[argv.index("--symbol") + 1], symbol)
        self.assertEqual(argv[argv.index("--sdk") + 1], "1.1.3")
        self.assertEqual(argv[argv.index("--platform") + 1], "Darwin-arm64")
        self.assertFalse(marker.exists())

    def test_unknown_tools_and_mutating_methods_never_execute(self):
        for name in ["verify", "build", "init", "exec", "list_symbols; whoami"]:
            with self.subTest(name=name):
                r = self.initialized(self.call(name))[-1]
                self.assertEqual(r["error"]["code"], -32602)
        r = self.initialized(request("verify", identifier=2))[-1]
        self.assertEqual(r["error"]["code"], -32601)
        self.assertEqual(self.calls(), [])

    def test_arguments_require_exact_environment_and_refuse_path_or_command_override(self):
        invalid = [{}, {"sdk": "1.1.3"}, {"platform": "Darwin-arm64"},
                   {"sdk": "", "platform": "Darwin-arm64"},
                   {"sdk": "1.1.3", "platform": "Darwin-arm64", "config": "/etc/passwd"},
                   {"sdk": "1.1.3", "platform": "Darwin-arm64", "binary": "/bin/sh"},
                   {"sdk": "1.1.3", "platform": "Darwin-arm64", "command": "echo unsafe"}]
        for name in ["get_verified_examples", "get_evidence"]:
            for args in invalid:
                with self.subTest(name=name, args=args):
                    self.assertEqual(self.initialized(self.call(name, args))[-1]["error"]["code"], -32602)
        for symbol in ["--config", "x\x00y", "x\ny", 12, True, "\ud800"]:
            self.assertEqual(self.initialized(self.call("list_symbols", {"symbol": symbol}))[-1]["error"]["code"], -32602)
        self.assertEqual(self.calls(), [])

    def test_missing_binary_and_config_are_clear_tool_errors(self):
        for options, expected in [({"binary": self.directory / "absent"}, "binary"),
                                  ({"config": self.directory / "absent.toml"}, "config")]:
            with self.subTest(options=options):
                result = self.initialized(self.call("list_symbols"), **options)[-1]["result"]
                self.assertTrue(result["isError"])
                self.assertIn(expected, result["content"][0]["text"])
        self.assertEqual(self.calls(), [])

    def test_native_nonzero_and_invalid_json_are_not_success(self):
        for symbol, expected in [("native-fail", "exit 7"), ("bad-json", "JSON")]:
            result = self.initialized(self.call("list_symbols", {"symbol": symbol}))[-1]["result"]
            self.assertTrue(result["isError"])
            self.assertIn(expected, result["content"][0]["text"])

    def test_protocol_validation_and_recovery(self):
        malformed = ["{", '{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}',
                     '{"jsonrpc":"2.0","id":NaN,"method":"ping"}']
        for source in malformed:
            replies = self.run_messages(source + "\n" + json.dumps(request("ping", identifier=8)) + "\n", raw=True)
            self.assertEqual(replies[0]["error"]["code"], -32700)
            self.assertEqual(replies[1]["result"], {})
        for value in [[], 1, {"jsonrpc": "1.0", "id": 2, "method": "ping"},
                      {"jsonrpc": "2.0", "id": True, "method": "ping"},
                      {"jsonrpc": "2.0", "id": None, "method": "ping"},
                      {"jsonrpc": "2.0", "id": 2, "method": 1}]:
            self.assertEqual(self.run_messages([value])[0]["error"]["code"], -32600)
        self.assertEqual(self.calls(), [])

    def test_initialization_required_and_tool_notifications_do_not_execute(self):
        reply = self.run_messages([request("tools/list")])[0]
        self.assertEqual(reply["error"]["code"], -32002)
        invalid_init = request("initialize", {"protocolVersion": 12}, identifier=2)
        self.assertEqual(self.run_messages([invalid_init])[0]["error"]["code"], -32602)
        notification = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "list_symbols", "arguments": {}}}
        responses = self.initialized(notification)
        self.assertEqual(len(responses), 1)
        self.assertEqual(self.calls(), [])

    def test_version_negotiation_duplicate_initialize_and_parameter_shapes(self):
        changed = dict(INITIALIZE, params=dict(INITIALIZE["params"], protocolVersion="2099-01-01"))
        self.assertEqual(self.run_messages([changed])[0]["result"]["protocolVersion"], "2025-06-18")
        self.assertEqual(self.initialized(INITIALIZE)[-1]["error"]["code"], -32600)
        for message in [request("tools/list", {"cursor": "arbitrary"}, 2),
                        request("tools/call", {"name": "list_symbols", "arguments": []}, 2),
                        request("tools/call", {"name": "list_symbols", "arguments": {}, "config": "/tmp/override"}, 2),
                        request("tools/call", [], 2)]:
            self.assertEqual(self.initialized(message)[-1]["error"]["code"], -32602)
        self.assertEqual(self.calls(), [])

    def test_oversize_and_invalid_utf8_are_parse_errors_with_frame_recovery(self):
        source = json.dumps({"x": "a" * (1024 * 1024)}) + "\n" + json.dumps(request("ping", identifier=8)) + "\n"
        replies = self.run_messages(source, raw=True)
        self.assertEqual(replies[0]["error"]["code"], -32700)
        self.assertEqual(replies[1]["result"], {})
        proc = subprocess.run([sys.executable, str(ADAPTER), "--binary", str(self.binary), "--config", str(self.config)],
                              input=b"\xff\n", capture_output=True, timeout=8)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(json.loads(proc.stdout)["error"]["code"], -32700)

    def test_native_environment_does_not_inherit_unrelated_credentials_unit_mock(self):
        spec = importlib.util.spec_from_file_location("mcp_env_test", ADAPTER)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        server = module.Server(self.config, self.binary)
        completed = subprocess.CompletedProcess([], 0, stdout=b"{}", stderr=b"")
        with patch.dict(os.environ, {"UNRELATED_SECRET": "unit-only-secret", "CJ_DOCGUARD_SDK_1_1_3": "/unit/sdk", "CJ_DOCGUARD_RUNNER": "/unit/runner"}):
            with patch.object(module.subprocess, "run", return_value=completed) as mocked:
                self.assertFalse(server.native_query("list_symbols", {})["isError"])
        environment = mocked.call_args.kwargs["env"]
        self.assertNotIn("UNRELATED_SECRET", environment)
        self.assertEqual(environment["CJ_DOCGUARD_SDK_1_1_3"], "/unit/sdk")
        self.assertEqual(environment["CJ_DOCGUARD_RUNNER"], "/unit/runner")
        self.assertEqual(mocked.call_args.kwargs["stdin"], subprocess.DEVNULL)

    def test_native_timeout_is_tool_error_unit_mock(self):
        spec = importlib.util.spec_from_file_location("mcp_stdio_test", ADAPTER)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        server = module.Server(self.config, self.binary)
        with patch.object(module.subprocess, "run", side_effect=subprocess.TimeoutExpired("unit fixture", 30)):
            result = server.native_query("list_symbols", {})
        self.assertTrue(result["isError"])
        self.assertIn("timeout", result["content"][0]["text"])



if __name__ == "__main__":
    unittest.main()
