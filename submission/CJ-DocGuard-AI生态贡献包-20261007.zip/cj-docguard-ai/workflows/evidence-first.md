# 仓颉证据查询与示例复现

适用对象：维护已登记仓颉项目的开发者和需要使用陌生接口的AI助手。项目配置、原生程序、SDK和平台由操作者在启动时确定。工具调用不接受任意路径、配置或执行命令。

1. 维护者审核源码、外部输入、SDK与例子断言，用CLI运行`verify --matrix`及`check --strict`。验证会运行本地程序；这一步不由MCP执行。
2. 助手查询声明：`list_symbols`，参数`{"symbol":"add"}`，用于确认当前名称和接口结构，不代表运行通过。
3. 助手查询示例：`get_verified_examples`，参数`{"symbol":"add","sdk":"1.1.3","platform":"Darwin-arm64"}`。
4. 助手查看证据：`get_evidence`，参数`{"example":"add","sdk":"1.1.3","platform":"Darwin-arm64"}`。检查`items`中的状态、当前性、断言、SDK、平台与尝试编号，记录响应中的实际编号，不填猜测编号。
5. 若`items=[]`，阅读`rejected`；若协议`error`或`isError=true`，说明错误并停止采用该证据。不用历史成功或别的环境替代。源码变化后重新查询；恢复源码也不能隐藏中间产生的较新失败，需维护者再次验证。
6. 在原生CLI中导出有效示例，SDK路径和平台必须与返回证据一致：

```bash
python3 scripts/dev.py run -- export --config /absolute/cj-docguard-ai/examples/reuse-project/docguard.toml --example add --sdk 1.1.3 --platform Darwin-arm64 --out /absolute/new-export-directory
cd /absolute/new-export-directory
CJ_SDK_HOME=/absolute/sdk-1.1.3/cangjie bash build.sh
```

先阅读导出源码与`manifest.json`。输出预期为`3`；其保证只限登记断言和记录环境。导出在CLI执行，MCP没有导出工具。将知识用于新代码后，在自己的正常流程中独立编译和测试。只读查询可能写私有探针日志，不构成只读操作系统或安全隔离。
