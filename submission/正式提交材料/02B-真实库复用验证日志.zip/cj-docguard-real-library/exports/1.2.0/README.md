# upstream-api · CJ-DocGuard export

This runnable bundle was built from frozen source and attempt 2.

Run: `CJ_SDK_HOME=/absolute/path/to/cangjie bash build.sh`

See `manifest.json` for the recorded SDK, platform, fingerprints and assertions.

证据冻结于导出时刻；输入或环境变化后当前性必须重新查询。运行通过仅证明登记断言在记录环境下通过，不证明 API 全部行为正确。
