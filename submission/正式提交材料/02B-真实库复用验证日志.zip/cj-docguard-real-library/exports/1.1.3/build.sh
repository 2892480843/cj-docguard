#!/usr/bin/env bash
# Generated 2026-10-07T20:06:17.04208+08:00 from attempt 1
set -euo pipefail
cd "$(dirname "$0")"
: "${CJ_SDK_HOME:?Set CJ_SDK_HOME to the recorded SDK root}"
export CANGJIE_HOME="$CJ_SDK_HOME"
export PATH="$CJ_SDK_HOME/bin:$CJ_SDK_HOME/tools/bin:$PATH"
[[ "$(uname -s)-$(uname -m)" == 'Darwin-arm64' ]] || { echo 'Platform differs from recorded evidence' >&2; exit 2; }
[[ "$("$CJ_SDK_HOME/bin/cjc" --version)" == *'Cangjie Compiler: 1.1.3 ('* ]] || { echo 'SDK differs from recorded evidence' >&2; exit 2; }
if [[ "$(uname -s)" == Darwin ]]; then
  export DYLD_LIBRARY_PATH="$CJ_SDK_HOME/runtime/lib/darwin_aarch64_cjnative"
  export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
else
  export LD_LIBRARY_PATH="$CJ_SDK_HOME/runtime/lib/linux_$(uname -m)_cjnative"
fi
"${CJ_SDK_HOME}/bin/cjc" './src/upstream/src/leven.cj' './main_wrapped.cj' '-o' './program'
./program
